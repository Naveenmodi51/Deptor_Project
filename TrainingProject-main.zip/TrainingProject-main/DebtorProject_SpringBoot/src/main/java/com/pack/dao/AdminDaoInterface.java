package com.pack.dao;

import com.pack.model.TransactionDetails;

public interface AdminDaoInterface 

{
public int authorize(TransactionDetails td);
}
