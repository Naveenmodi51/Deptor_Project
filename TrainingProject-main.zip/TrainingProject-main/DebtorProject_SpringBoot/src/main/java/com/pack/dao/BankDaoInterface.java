package com.pack.dao;

import com.pack.model.BankDetails;

public interface BankDaoInterface
{
public int save(BankDetails bnk);
}
