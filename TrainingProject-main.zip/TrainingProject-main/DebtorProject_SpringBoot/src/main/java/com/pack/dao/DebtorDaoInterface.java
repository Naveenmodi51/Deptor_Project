package com.pack.dao;

import com.pack.model.DebtorDetails;

public interface DebtorDaoInterface 
{
public int save(DebtorDetails u);
}
