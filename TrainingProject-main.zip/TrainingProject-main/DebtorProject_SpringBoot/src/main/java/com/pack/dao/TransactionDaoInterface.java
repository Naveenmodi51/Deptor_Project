package com.pack.dao;

import com.pack.model.TransactionDetails;

public interface TransactionDaoInterface
{
public int save(TransactionDetails td);

}
