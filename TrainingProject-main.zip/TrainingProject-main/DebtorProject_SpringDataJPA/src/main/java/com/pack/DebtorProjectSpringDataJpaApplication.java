package com.pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DebtorProjectSpringDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DebtorProjectSpringDataJpaApplication.class, args);
	}

}
