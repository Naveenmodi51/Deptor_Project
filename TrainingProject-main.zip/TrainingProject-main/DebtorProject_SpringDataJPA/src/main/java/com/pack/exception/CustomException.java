package com.pack.exception;

public class CustomException extends Exception

{

}
